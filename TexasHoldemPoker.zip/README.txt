
THE FOLLOWING IS ALSO IN THE DOCUMENT: USER DOCUMENTATION: ONLINE TEXAS HOLD'EM POKER
--------------------------------------------------------------------------------------------
Installation Guide
--------------------------------------------------------------------------------------------
• The game is best enjoyed on Google Chrome. If not already the case, please install Google
Chrome and ensure that it is your default browser.

• Unzip the files out of the TexasHoldemPoker.zip file provided.

• Install Visual Studio Code on your device

• On Linux: In the terminal, type the following
	sudo snap install --classic code

• Within VScode, head to the extensions tab (or use ctrl+shift+X)

• Search for the ”Live Server” Extension and install it.

• File - Open folder

• Select the folder named ”THEGame” (not the parent or child folders)

• From the file hierarchy in VScode, open the TittleScreen.html file.

• Right-click anywhere on the code and select the ”Open with Live Server” option.

--------------------------------------------------------------------------------------------
End-User Guide
--------------------------------------------------------------------------------------------
Sign In Page:

• Enter your username: ”Jandre”
• Enter your password: ”password”
• Click on the Sign In button

Leaderboard/Lobby page:

• Look at the leader board if you so wish
• Press START when ready


Game page:

Press the start button - this will commence the dealing, small blind, big blind, and ”AI
Player 4’s” first turn (they raise).

• Now the player has a choice between folding and calling. Folding will end the game. Press
call to continue with the game. This will lead the opponents to call or check and then the
”Flop” (first three community cards will be revealed) occurs.


• From now on the player can raise, fold or check.
• When the player raises, the opponents (the ”AI”) will call to match.
• When the player checks, all opponents check as well and the game moves on to the next
state: the ”Turn” (fourth community card gets revealed).


• The player can raise, check or fold.
• If the player checks, the game will move on to the ”River” state (all community cards
revealed).

• The player can again: raise, check or fold.
• If they check, the game will move to the final state: ”Showdown” (all player cards revealed).
• The player will not be able to call, raise, fold or check anymore.
• From this point, it is determined whether the player won, lost or ended up in a tie.

• After the Showdown, the player can click on ”Go To Lobby” to return to the lobby and start
a new game.
