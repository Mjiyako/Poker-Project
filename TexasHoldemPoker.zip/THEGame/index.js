
//array of images to be displayed on game HTML page
const imageArray = [
    "/AllCards/2TwoClub.png",
    "/AllCards/2TwoDiamond.png",
    "/AllCards/2TwoHeart.png",
    "/AllCards/2TwoSpade.png",
    "/AllCards/3ThreeClub.png",
    "/AllCards/3ThreeDiamond.png",
    "/AllCards/3ThreeHeart.png",
    "/AllCards/3ThreeSpade.png",
    "/AllCards/4FourClub.png",
    "/AllCards/4FourDiamond.png",
    "/AllCards/4FourHeart.png",
    "/AllCards/4FourSpade.png",
    "/AllCards/5FiveClub.png",
    "/AllCards/5FiveDiamond.png",
    "/AllCards/5FiveHeart.png",
    "/AllCards/5FiveSpade.png",
    "/AllCards/6SixClub.png",
    "/AllCards/6SixDiamond.png",
    "/AllCards/6SixHeart.png",
    "/AllCards/6SixSpade.png",
    "/AllCards/7SevenClub.png",
    "/AllCards/7SevenDiamond.png",
    "/AllCards/7SevenHeart.png",
    "/AllCards/7SevenSpade.png",
    "/AllCards/8EightClub.png",
    "/AllCards/8EightDiamond.png",
    "/AllCards/8EightHeart.png",
    "/AllCards/8EightSpade.png",
    "/AllCards/9NineClub.png",
    "/AllCards/9NineDiamond.png",
    "/AllCards/9NineHeart.png",
    "/AllCards/9NineSpade.png",
    "/AllCards/10TenClub.png",
    "/AllCards/10TenDiamond.png",
    "/AllCards/10TenHeart.png",
    "/AllCards/10TenSpade.png",
    "/AllCards/11JackClub.png",
    "/AllCards/11JackDiamond.png",
    "/AllCards/11JackHeart.png",
    "/AllCards/11JackSpade.png",
    "/AllCards/12QueenClub.png",
    "/AllCards/12QueenDiamond.png",
    "/AllCards/12QueenHeart.png",
    "/AllCards/12QueenSpade.png",
    "/AllCards/13KingClub.png",
    "/AllCards/13KingDiamond.png",
    "/AllCards/13KingHeart.png",
    "/AllCards/13KingSpade.png",
    "/AllCards/1AceClub.png",
    "/AllCards/1AceDiamond.png",
    "/AllCards/1AceHeart.png",
    "/AllCards/1AceSpade.png"
]; 

//List of possible hands in order of value in end game scoring
//i.e., index corresponds to the score the hand will get you
let hands = ["Two High Card","Three High Card","Four High Card","Five High Card","Six High Card","Seven High Card",
"Eight High Card","Nine High Card","Ten High Card","Jack High Card","Queen High Card","King High Card","Ace High Card",
"Pair of Twos", "Pair of Threes", "Pair of Fours", "Pair of Fives", "Pair of Sixes", "Pair of Sevens", "Pair of Eigths", 
"Pair of Nines", "Pair of Tens", "Pair of Jacks", "Pair of Queens", "Pair of Kings", "Pair of Aces",
"Three of a Kind: Twos", "Three of a Kind: Threes", "Three of a Kind: Fours", "Three of a Kind: Fives", "Three of a Kind: Sixes", 
"Three of a Kind: Sevens", "Three of a Kind: Eights","Three of a Kind: Nines", "Three of a Kind: Tens", "Three of a Kind: Jacks", 
"Three of a Kind: Queens", "Three of a Kind: Kings", "Three of a Kind: Aces",
"Straight (A-5)","Straight (2-6)","Straight (3-7)","Straight (4-8)","Straight (5-9)","Straight (6-10)",
"Straight (7-J)","Straight (8-Q)","Straight (9-K)","Straight (10-A)",
"Flush (2)","Flush (3)","Flush (4)","Flush (5)","Flush (6)","Flush (7)","Flush (8)","Flush (9)","Flush (10)",
"Flush (J)","Flush (Q)","Flush (K)","Flush (A)",
"Full House (2)","Full House (3)","Full House (4)","Full House (5)","Full House (6)","Full House (7)","Full House (8)",
"Full House (9)","Full House (10)","Full House (J)","Full House (Q)","Full House (K)","Full House (A)",
"Four of a Kind: Twos", "Four of a Kind: Threes", "Four of a Kind: Fours", "Four of a Kind: Fives", "Four of a Kind: Sixes", 
"Four of a Kind: Sevens", "Four of a Kind: Eights","Four of a Kind: Nines", "Four of a Kind: Tens", "Four of a Kind: Jacks", 
"Four of a Kind: Queens", "Four of a Kind: Kings", "Four of a Kind: Aces",
"Straight Flush (A-5)","Straight Flush (2-6)","Straight Flush (3-7)","Straight Flush (4-8)","Straight Flush (5-9)","Straight Flush (6-10)",
"Straight Flush (7-J)","Straight Flush (8-Q)","Straight Flush (9-K)","Royal Flush (A,K,Q,J,10)"
];

//array parallel to image array to store suit data or each card drawn
let image_suit_parallel_array = [
    "Club","Diamond", "Heart", "Spade",
    "Club","Diamond", "Heart", "Spade",
    "Club","Diamond", "Heart", "Spade",
    "Club","Diamond", "Heart", "Spade",
    "Club","Diamond", "Heart", "Spade",
    "Club","Diamond", "Heart", "Spade",
    "Club","Diamond", "Heart", "Spade",
    "Club","Diamond", "Heart", "Spade",
    "Club","Diamond", "Heart", "Spade",
    "Club","Diamond", "Heart", "Spade",
    "Club","Diamond", "Heart", "Spade",
    "Club","Diamond", "Heart", "Spade",
    "Club","Diamond", "Heart", "Spade"
];

//array parallel to image array to store face data or each card drawn
let image_face_parallel_array = [
    2,2,2,2,
    3,3,3,3,
    4,4,4,4,
    5,5,5,5,
    6,6,6,6,
    7,7,7,7,
    8,8,8,8,
    9,9,9,9,
    10,10,10,10,
    11,11,11,11,
    12,12,12,12,
    13,13,13,13,
    1,1,1,1
];

// variables storing specific suits and faces of cards drawn by players 
// tp be used when calculating scores and text hints

let p1c1_Face, p1c1_Suit, p1c2_Face, p1c2_Suit, 
      p2c1_Face, p2c1_Suit, p2c2_Face, p2c2_Suit, 
      p3c1_Face, p3c1_Suit, p3c2_Face, p3c2_Suit, 
      p4c1_Face, p4c1_Suit, p4c2_Face, p4c2_Suit, 
      cc1_Face, cc1_Suit, cc2_Face, cc2_Suit, cc3_Face, cc3_Suit, cc4_Face, cc4_Suit , cc5_Face, cc5_Suit
; 

//for random card draw
let randomNum;

// tells player what hand they have
let textHint;

let checkCounter;

let p1dupArray;


// temporary storage of card image sources for delayed display (necessary since items are removed from image and parallel arrays)
let p2c1_SrcTemp, p2c2_SrcTemp, p3c1_SrcTemp, p3c2_SrcTemp, p4c1_SrcTemp, p4c2_SrcTemp,
      cc1_SrcTemp, cc2_SrcTemp, cc3_SrcTemp, cc4_SrcTemp, cc5_SrcTemp;
      

//let p1c1_index, p1c2_index, p2c1_index, p2c2_index, p3c1_index, p3c2_index, p4c1_index, p4c2_index,
//      cc1_index, cc2_index, cc3_index, cc4_index, cc5_index;

 
// stores the amount of chips each player has
let player1_chips, player2_chips, player3_chips, player4_chips;

let pot = 0;

//for first round raise of player 4
let P4raiseBetAmount;

//raise amount for the main player when raise button is clicked 
let playerRaiseAmount;

//variables keeping track of what was bet 
let currentBetAmount, previousBetAmount;

//variables for endgame scoring 
let p1Score, p2Score, p3Score, p4Score = 0;

// to check if players are folded or not
let player1_folded, player2_folded, player3_folded,  player4_folded = false;

//game state 
//preflop , flop , turn , river, showdown
let State;

//to check whose turn it is (myTurn, theirTurn)
let playerTurn; 

//when this button is clicked the game starts i.e., the preflop start function runs
const startbutton = document.getElementById('startButton');

// these are player action buttons
const foldButton = document.querySelector('#foldButton');
const callButton = document.querySelector('#callButton');
const raiseButton = document.querySelector('#raiseButton');
const checkButton = document.querySelector('#checkButton');



// on click event for player action buttons and start button
startbutton.addEventListener("click", () => PreFlopStart());
callButton.addEventListener("click", () => OnCallClick());
raiseButton.addEventListener("click", () => OnRaiseClick());
foldButton.addEventListener("click", () => OnFoldClick());
checkButton.addEventListener("click", () => OnCheckClick());


disableButtons();



//PREFLOP START FUNCTION :
                         // DEALING MECHANIC - using random number generation cards are removed(.splice) from the image array as well as data from the parallel arrays.

                         //The player images are immediately to the user (player 1 images), all other cards are stored in temporary src variables to be used in later start state functions.

                         // BLINDS MECHANIC - small and big blind done on behalf of the players.
                         // AI 4 - raises 
                         // at this point the player can call or fold.
                         
function PreFlopStart(){
    disableButtons();

    document.getElementById('startButton').style.visibility = "hidden";
    
    //startbutton.disabled;
    State = "Preflop";

    //Debuging
    playerTurn = "theirTurn";
    //---------
    //dealing---------------------------------------------------------
    //p1c1 (player 1 card 1)
    randomNum = Math.floor(Math.random() * imageArray.length); 
	document.getElementById('Player1-card1').setAttribute("src", imageArray[randomNum]);
   // p1c1_index = randomNum;
    p1c1_Face =  image_face_parallel_array[randomNum];
    p1c1_Suit =  image_suit_parallel_array[randomNum];
    imageArray.splice((randomNum) | 0, 1);
    image_face_parallel_array.splice((randomNum) | 0, 1);
    image_suit_parallel_array.splice((randomNum) | 0, 1);

    //p1c2
    randomNum = Math.floor(Math.random() * imageArray.length); 
	document.getElementById('Player1-card2').setAttribute("src", imageArray[randomNum]);
   // p1c2_index = randomNum;
    p1c2_Face =  image_face_parallel_array[randomNum];
    p1c2_Suit =  image_suit_parallel_array[randomNum];
    imageArray.splice((randomNum) | 0, 1);
    image_face_parallel_array.splice((randomNum) | 0, 1);
    image_suit_parallel_array.splice((randomNum) | 0, 1);

    //p2c1
    randomNum = Math.floor(Math.random() * imageArray.length); 
	//document.getElementById('Player2-card1').setAttribute("src", imageArray[randomNum]);
    p2c1_SrcTemp = imageArray[randomNum];
    //document.getElementById('Player2-card1').setAttribute("src", p2c1_SrcTemp);
    p2c1_Face =  image_face_parallel_array[randomNum];
    p2c1_Suit =  image_suit_parallel_array[randomNum];
    imageArray.splice((randomNum) | 0, 1);
    image_face_parallel_array.splice((randomNum) | 0, 1);
    image_suit_parallel_array.splice((randomNum) | 0, 1);

    //p2c2
    randomNum = Math.floor(Math.random() * imageArray.length); 
	//document.getElementById('Player1-card2').setAttribute("src", imageArray[randomNum]);
    p2c2_SrcTemp = imageArray[randomNum];
    p2c2_Face =  image_face_parallel_array[randomNum];
    p2c2_Suit =  image_suit_parallel_array[randomNum];
    imageArray.splice((randomNum) | 0, 1);
    image_face_parallel_array.splice((randomNum) | 0, 1);
    image_suit_parallel_array.splice((randomNum) | 0, 1);

    //p3c1
    randomNum = Math.floor(Math.random() * imageArray.length); 
	//document.getElementById('Player2-card1').setAttribute("src", imageArray[randomNum]);
    p3c1_SrcTemp = imageArray[randomNum];
    p3c1_Face =  image_face_parallel_array[randomNum];
    p3c1_Suit =  image_suit_parallel_array[randomNum];
    imageArray.splice((randomNum) | 0, 1);
    image_face_parallel_array.splice((randomNum) | 0, 1);
    image_suit_parallel_array.splice((randomNum) | 0, 1);

    //p3c2
    randomNum = Math.floor(Math.random() * imageArray.length); 
	//document.getElementById('Player3-card2').setAttribute("src", imageArray[randomNum]);
    p3c2_SrcTemp = imageArray[randomNum];
    p3c2_Face =  image_face_parallel_array[randomNum];
    p3c2_Suit =  image_suit_parallel_array[randomNum];
    imageArray.splice((randomNum) | 0, 1);
    image_face_parallel_array.splice((randomNum) | 0, 1);
    image_suit_parallel_array.splice((randomNum) | 0, 1);

    //p4c1
    randomNum = Math.floor(Math.random() * imageArray.length); 
	//document.getElementById('Player2-card1').setAttribute("src", imageArray[randomNum]);
    p4c1_SrcTemp = imageArray[randomNum];
    p4c1_Face =  image_face_parallel_array[randomNum];
    p4c1_Suit =  image_suit_parallel_array[randomNum];
    imageArray.splice((randomNum) | 0, 1);
    image_face_parallel_array.splice((randomNum) | 0, 1);
    image_suit_parallel_array.splice((randomNum) | 0, 1);

    //p4c2
    randomNum = Math.floor(Math.random() * imageArray.length); 
	//document.getElementById('Player1-card2').setAttribute("src", imageArray[randomNum]);
    p4c2_SrcTemp = imageArray[randomNum];
    p4c2_Face =  image_face_parallel_array[randomNum];
    p4c2_Suit =  image_suit_parallel_array[randomNum];
    imageArray.splice((randomNum) | 0, 1);
    image_face_parallel_array.splice((randomNum) | 0, 1);
    image_suit_parallel_array.splice((randomNum) | 0, 1);

    //cc1
    randomNum = Math.floor(Math.random() * imageArray.length); 
	//document.getElementById('Player1-card2').setAttribute("src", imageArray[randomNum]);
    cc1_SrcTemp = imageArray[randomNum];
    cc1_Face =  image_face_parallel_array[randomNum];
    cc1_Suit =  image_suit_parallel_array[randomNum];
    imageArray.splice((randomNum) | 0, 1);
    image_face_parallel_array.splice((randomNum) | 0, 1);
    image_suit_parallel_array.splice((randomNum) | 0, 1);

    //cc2
    randomNum = Math.floor(Math.random() * imageArray.length); 
	//document.getElementById('Player1-card2').setAttribute("src", imageArray[randomNum]);
    cc2_SrcTemp = imageArray[randomNum];
    cc2_Face =  image_face_parallel_array[randomNum];
    cc2_Suit =  image_suit_parallel_array[randomNum];
    imageArray.splice((randomNum) | 0, 1);
    image_face_parallel_array.splice((randomNum) | 0, 1);
    image_suit_parallel_array.splice((randomNum) | 0, 1);

    //cc3
    randomNum = Math.floor(Math.random() * imageArray.length); 
	//document.getElementById('Player1-card2').setAttribute("src", imageArray[randomNum]);
    cc3_SrcTemp = imageArray[randomNum];
    cc3_Face =  image_face_parallel_array[randomNum];
    cc3_Suit =  image_suit_parallel_array[randomNum];
    imageArray.splice((randomNum) | 0, 1);
    image_face_parallel_array.splice((randomNum) | 0, 1);
    image_suit_parallel_array.splice((randomNum) | 0, 1);

    //cc4
    randomNum = Math.floor(Math.random() * imageArray.length); 
	//document.getElementById('Player1-card2').setAttribute("src", imageArray[randomNum]);
    cc4_SrcTemp = imageArray[randomNum];
    cc4_Face =  image_face_parallel_array[randomNum];
    cc4_Suit =  image_suit_parallel_array[randomNum];
    imageArray.splice((randomNum) | 0, 1);
    image_face_parallel_array.splice((randomNum) | 0, 1);
    image_suit_parallel_array.splice((randomNum) | 0, 1);

    //cc5
    randomNum = Math.floor(Math.random() * imageArray.length); 
	//document.getElementById('Player1-card2').setAttribute("src", imageArray[randomNum]);
    cc5_SrcTemp = imageArray[randomNum];
    cc5_Face =  image_face_parallel_array[randomNum];
    cc5_Suit =  image_suit_parallel_array[randomNum];
    imageArray.splice((randomNum) | 0, 1);
    image_face_parallel_array.splice((randomNum) | 0, 1);
    image_suit_parallel_array.splice((randomNum) | 0, 1);
    //----------------------------------------------------------------
   
   
   
    //Players initial amounts---------------------------------------------------------------
    player1_chips = 500;
    player2_chips = 500;
    player3_chips = 500;
    player4_chips = 500;
    pot = 0;
    //Blinds----------------------------------------------------------
    setTimeout(function(){
        document.getElementById('turnIndicator').innerHTML = `<h4>Dealing Starts</h4>`
    },1000)
    //small blind
    setTimeout(function()
        { 
            document.getElementById('turnIndicator').innerHTML = `<h4>Small Blind</h4>`
            currentBetAmount = 5;
            player2_chips = player2_chips - currentBetAmount;
            pot = pot + currentBetAmount;

             document.getElementById('player2Chips').innerHTML = `<span>${player2_chips}</span>`;
             document.getElementById('player2Acts').innerHTML = `<p>Small Blind</p>`;
             document.getElementById('potChips').innerHTML = `<span>${pot}</span>`;
        },1500)   
           

    setTimeout(function()
    {
        //big blind
        document.getElementById('turnIndicator').innerHTML = `<h4>Big Blind</h4>`
    currentBetAmount = 10;
    player3_chips -= currentBetAmount;
    pot += currentBetAmount;

    document.getElementById('player3Chips').innerHTML = `<span>${player3_chips}</span>`;
    document.getElementById('player3Acts').innerHTML = `<p>Big Blind</p>`;
    document.getElementById('potChips').innerHTML = `<span>${pot}</span>`;
    document.getElementById('turnIndicator').innerHTML = `<h4>AI-David's Turn</h4>`
    },2000)


    //Delay before 4th players action------------------------------------------- 
       setTimeout(function() {
        P4raiseBetAmount = 20;
        player4_chips = player4_chips - P4raiseBetAmount;
        document.getElementById('player4Chips').innerHTML = `<span>${player4_chips}</span>`;
        document.getElementById('player4Acts').innerHTML = `<p>Raised</p>`;
        document.getElementById('turnIndicator').innerHTML = `<h4>Your Turn</h4>`
        availableButtons(); //re-enable relevant buttons
        pot = pot + P4raiseBetAmount;
        document.getElementById('potChips').innerHTML = `<span>${pot}</span>`;
        //previousBetAmount = P4raiseBetAmount;
        document.querySelector("#raiseButton").disabled = true; 

       }, 2500);
    //End of Delay before 4th players action-------------------------------------

    



  //  document.getElementById('player3Chips').innerHTML = ``
    //----------------------------------------------------------------

    //AI player 4 does his check_________

    //___________________________________

    //then comes player action
   

}


//CHECKHAND FUNCTION : 
                    // uses functions: findDuplicates, calcDuplicates, arraysEqual and findSequence. 
                    // with the above-mentioned function the faces and suits are placed in readable array format.
                    //cards are checked in ascending order or hand value so that lower scoring hands are overwritten by better hands.
                    //changes the text hint variable 
                                    

function checkHand(arrayFaces,arraySuits)  // [2,2,3,5,6],['Heart','Spade','Clubs','Diamond','Heart']
{
    //check for straights
    arrayFaces = arrayFaces.sort(function (a, b) {  return a - b;  });


    //-----------------------------------------------------------------------------------
    //find what faces are duplicated (for pairs, 3 of a kind, 4 of a kind, full house)
    let dupArray = findDuplicates(arrayFaces);  // [2]
    //make array that shows how many times a card gets duplicated (pair vs 3 of a kind vs ... etc)
    let checkArray = calcDuplicates(dupArray, arrayFaces);  // [2] [2,2,3,5,6] -> [2,0,0]

    let newArray1 = [0,0,0];//High card (no dups)
    let newArray2 = [2,0,0];//Pair (one double)
    let newArray3 = [2,2,0];//two Pair (two doubles)
    let newArray4 = [2,2,2];//three Pair (3 doubles) -> two pair (hand only out of 5 cards)
    let newArray5 = [3,0,0];//3 of a kind (one tripple)
    let newArray6 = [3,3,0];//two 3 of a kind (two tripples) -> full house (hand only out of 5 cards)
    let newArray7 = [3,2,0];//Full house (one tripple and one double)
    let newArray8 = [2,3,0];//Full house (one tripple and one double)
    let newArray9 = [4,0,0];//Four of a Kind (one quad)
    let newArray10 = [3,2,2];//Full house (second pair ignored)
    let newArray11 = [2,3,2];//Full house (second pair ignored)
    let newArray12 = [2,2,3];//Full house (second pair ignored)

    
    //check for royalty
    let hasAce = false;
    let hasKing = false;
    let hasQueen = false;
    let hasJack = false;
    let hasTen = false;
    

    if ( arrayFaces.includes(1)) {
        hasAce = true;
    }
    if ( arrayFaces.includes(13)) {
        hasKing = true;
    }
    if ( arrayFaces.includes(10)) {
        hasTen = true;
    }
    if ( arrayFaces.includes(11)) {
        hasJack = true;
    }
    if ( arrayFaces.includes(12)) {
        hasQueen = true;
    }
    
    //check for flushes
    let dupArray2 = findDuplicates(arraySuits); // dupArray2 = [heart]

    //Two possible checkArray's for a flush
    let newArrayA = [5,0,0];
    let newArrayB = [5,2,0];
    let checkArray2 = calcDuplicates(dupArray2, arraySuits);

    //check which array it is.
    if (arraysEqual(checkArray, newArray1))
    {
        textHint = "High Card";
    }
    
    if (arraysEqual(checkArray, newArray2 ))
    {
        textHint = "Pair";
    }
    
    if (arraysEqual(checkArray, newArray3 ) || arraysEqual(checkArray, newArray4 ))
    {
        textHint = "Two Pair";
    } 
    
    if (arraysEqual(checkArray, newArray5 ))
    {
        textHint = "Three of a Kind";
    }
    
    if (findSequence(arrayFaces) === 4) {
        textHint = "Straight";
    }
    
    if ( ( arraysEqual(checkArray2,newArrayA) || arraysEqual(checkArray2,newArrayB) ) )
    {
        textHint = "Flush";
    }
    
    if (arraysEqual(checkArray, newArray6 ) || arraysEqual(checkArray, newArray7 ) || arraysEqual(checkArray, newArray8 )
            || arraysEqual(checkArray, newArray10 ) || arraysEqual(checkArray, newArray11 ) || arraysEqual(checkArray, newArray12 ))
    {
        textHint = "Full House"; //"Two Three of a Kind" or "3 of a kind and two pairs";
    }
    
    if (arraysEqual(checkArray, newArray9))
    {
        textHint = "Four of a Kind";
    }
    
    if (findSequence(arrayFaces) === 4 && arraysEqual(checkArray2,newArrayA) || 
        findSequence(arrayFaces) === 4 && arraysEqual(checkArray2,newArrayB))
        {
            textHint = "Straight Flush";
        }
    
    if   ( (hasAce === true && hasKing === true && hasTen === true && hasQueen === true && hasJack === true) && ( arraysEqual(checkArray2,newArrayA) || arraysEqual(checkArray2,newArrayB) ) )  
         {
              textHint = "Royal Flush";
         }

            return  textHint;

    
    
    //-----------------------------------------------------------------------------------
}


//CHECKHAND POSTFLOP FUNCTION:  
                    // inputs into check hand function after the flop 
                    // i.e., the player 1 cards and the first three community cards ONLY are used as input for checkhand
                    
function checkHandPostFlop(){
    
   
    //initialize texthint (player will ALWAYS at least have High Card)
    textHint = "High Card";

    //arrays to check post flop
    let arrayFaces = [p1c1_Face , p1c2_Face , cc1_Face, cc2_Face, cc3_Face];
    let arraySuits = [p1c1_Suit , p1c2_Suit , cc1_Suit, cc2_Suit, cc3_Suit];

    checkHand(arrayFaces,arraySuits);


    document.getElementById('playerHints').innerHTML = `<span>${textHint}</span>`
    
   
}


//CHECKHAND POSTTURN FUNCTION:  
                    // inputs into check hand function after the Turn 
                    // i.e., the player 1 cards and the first four community cards ONLY are used as input for checkhand
                    
function checkHandPostTurn(){
    //initialize texthint (player will ALWAYS at least have High Card)
    textHint = "High Card";

    //arrays to check post flop
    let arrayFaces = [p1c1_Face , p1c2_Face , cc1_Face, cc2_Face, cc3_Face, cc4_Face];
    let arraySuits = [p1c1_Suit , p1c2_Suit , cc1_Suit, cc2_Suit, cc3_Suit, cc4_Suit];

    checkHand(arrayFaces,arraySuits);

    document.getElementById('playerHints').innerHTML = `<span>${textHint}</span>`

  
}


//CHECKHAND POSTRIVER FUNCTION:  
                    // inputs into check hand function after the River 
                    // i.e., the player 1 cards and all community cards ONLY are used as input for checkhand
                    // inputs into the score hand functions after the river  (for all players)
                    
function checkHandPostRiver(){
    //initialize texthint (player will ALWAYS at least have High Card)
    //textHint = "High Card";

    //arrays to check post flop
    let arrayFaces = [p1c1_Face , p1c2_Face , cc1_Face, cc2_Face, cc3_Face, cc4_Face, cc5_Face];
    let arraySuits = [p1c1_Suit , p1c2_Suit , cc1_Suit, cc2_Suit, cc3_Suit, cc4_Suit, cc5_Suit];

    checkHand(arrayFaces,arraySuits);

    let arrayScoringP1Faces = [p1c1_Face , p1c2_Face , cc1_Face, cc2_Face, cc3_Face, cc4_Face, cc5_Face];
    let arrayScoringP1Suits = [p1c1_Suit , p1c2_Suit , cc1_Suit, cc2_Suit, cc3_Suit, cc4_Suit, cc5_Suit];
    let arrayScoringP2Faces = [p2c1_Face , p2c2_Face , cc1_Face, cc2_Face, cc3_Face, cc4_Face, cc5_Face];
    let arrayScoringP2Suits = [p2c1_Suit , p2c2_Suit , cc1_Suit, cc2_Suit, cc3_Suit, cc4_Suit, cc5_Suit];
    let arrayScoringP3Faces = [p3c1_Face , p3c2_Face , cc1_Face, cc2_Face, cc3_Face, cc4_Face, cc5_Face];
    let arrayScoringP3Suits = [p3c1_Suit , p3c2_Suit , cc1_Suit, cc2_Suit, cc3_Suit, cc4_Suit, cc5_Suit];
    let arrayScoringP4Faces = [p4c1_Face , p4c2_Face , cc1_Face, cc2_Face, cc3_Face, cc4_Face, cc5_Face];
    let arrayScoringP4Suits = [p4c1_Suit , p4c2_Suit , cc1_Suit, cc2_Suit, cc3_Suit, cc4_Suit, cc5_Suit];

    checkHand(arrayScoringP2Faces,arrayScoringP2Suits);
    document.getElementById('player2Role').innerHTML = `<p>${textHint}</p>`;

    checkHand(arrayScoringP3Faces,arrayScoringP3Suits);
    document.getElementById('player3Role').innerHTML = `<p>${textHint}</p>`;

    checkHand(arrayScoringP4Faces,arrayScoringP4Suits);
    document.getElementById('player4Role').innerHTML = `<p>${textHint}</p>`;


    scoreHandP1(arrayScoringP1Faces,arrayScoringP1Suits);
    scoreHandP2(arrayScoringP2Faces,arrayScoringP2Suits);
    scoreHandP3(arrayScoringP3Faces,arrayScoringP3Suits);
    scoreHandP4(arrayScoringP4Faces,arrayScoringP4Suits);
    let scoreResult;
    scoreResult = compareScores();
    document.getElementById('gameStatus').style.visibility = "visible";
    document.getElementById('gameStatus').setAttribute("src", scoreResult);

    //let scoreArray = [p1Score,p2Score,p3Score,p4Score];


    
    if ( p1Score > p2Score && p1Score > p3Score && p1Score > p4Score) {
        
        if (pot>0) {
            player1_chips = player1_chips + pot;
            pot = pot-pot;

        }else{}
        
        document.getElementById('player1Chips').innerHTML = `<span>${player1_chips}</span>`;
        document.getElementById('potChips').innerHTML = `<span>${pot}</span>`;

    } else if ( p2Score > p1Score && p2Score > p3Score && p2Score > p4Score) {
        if(pot>0){
        player2_chips = player2_chips + pot;
        pot = pot-pot;
        }else{}

        document.getElementById('player2Chips').innerHTML = `<span>${player2_chips}</span>`;
        document.getElementById('potChips').innerHTML = `<span>${pot}</span>`;

    } else if ( p3Score > p2Score && p3Score > p1Score && p3Score > p4Score) {
        if (pot>0) {
            player3_chips = player3_chips + pot;
             pot = pot-pot;
        }else{}
        

        document.getElementById('player3Chips').innerHTML = `<span>${player3_chips}</span>`;
        document.getElementById('potChips').innerHTML = `<span>${pot}</span>`;

    } else if ( p4Score > p2Score && p4Score > p3Score && p4Score > p1Score) {
        
        if (pot>0) {
            player4_chips = player4_chips + pot;
            pot = pot-pot;
        }else{}
        
        document.getElementById('player4Chips').innerHTML = `<span>${player4_chips}</span>`;
        document.getElementById('potChips').innerHTML = `<span>${pot}</span>`;
    } else{
        {
        for (let i = 0; i < scoreArray.length; i++) {
            for (let j = 0; j < scoreArray.length; j++) {
                 if (i!=j) {
                    if (scoreArray[i]===scoreArray[j]) {
                        let scoreResult = "/WinLoseImages/TieCard.png";
                        document.getElementById('gameStatus').setAttribute("src", scoreResult);
                        document.getElementById('gameStatus').style.visibility = "visible";
                    }
                 }
                
            }
            
        }

      }
        
    }

}


//SCORE HAND FUNCTION: 
                   // Similar to the check hand function but instead of the text hind variables being changed, the scores of the players are changed.
                   
function scoreHand(arrayFaces,arraySuits)
{
    //check for straights
    let playerScore = 0;
    arrayFaces = arrayFaces.sort(function (a, b) {  return a - b;  });


    //-----------------------------------------------------------------------------------
    //find what faces are duplicated (for pairs, 3 of a kind, 4 of a kind, full house)
    let dupArray = findDuplicates(arrayFaces);  // [2]
    //make array that shows how many times a card gets duplicated (pair vs 3 of a kind vs ... etc)
    let checkArray = calcDuplicates(dupArray, arrayFaces);  // [2] [2,2,3,5,6] -> [2,0,0]

    let newArray1 = [0,0,0];//High card (no dups)
    let newArray2 = [2,0,0];//Pair (one double)
    let newArray3 = [2,2,0];//two Pair (two doubles)
    let newArray4 = [2,2,2];//three Pair (3 doubles) -> two pair (hand only out of 5 cards)
    let newArray5 = [3,0,0];//3 of a kind (one tripple)
    let newArray6 = [3,3,0];//two 3 of a kind (two tripples) -> full house (hand only out of 5 cards)
    let newArray7 = [3,2,0];//Full house (one tripple and one double)
    let newArray8 = [2,3,0];//Full house (one tripple and one double)
    let newArray9 = [4,0,0];//Four of a Kind (one quad)
    let newArray10 = [3,2,2];//Full house (second pair ignored)
    let newArray11 = [2,3,2];//Full house (second pair ignored)
    let newArray12 = [2,2,3];//Full house (second pair ignored)

    
    //check for royalty
    let hasAce = false;
    let hasKing = false;
    let hasQueen = false;
    let hasJack = false;
    let hasTen = false;
    

    if ( arrayFaces.includes(1)) {
        hasAce = true;
    }
    if ( arrayFaces.includes(13)) {
        hasKing = true;
    }
    if ( arrayFaces.includes(10)) {
        hasTen = true;
    }
    if ( arrayFaces.includes(11)) {
        hasJack = true;
    }
    if ( arrayFaces.includes(12)) {
        hasQueen = true;
    }
    
    //check for flushes
    let dupArray2 = findDuplicates(arraySuits); // dupArray2 = [heart]

    //Two possible checkArray's for a flush
    let newArrayA = [5,0,0];
    let newArrayB = [5,2,0];
    let checkArray2 = calcDuplicates(dupArray2, arraySuits);

    //check which array it is.
    if (arraysEqual(checkArray, newArray1))
    {
        playerScore = 1;
    }
    
    if (arraysEqual(checkArray, newArray2 ))
    {
        playerScore = 2;
    }
    
    if (arraysEqual(checkArray, newArray3 ) || arraysEqual(checkArray, newArray4 ))
    {
        playerScore = 3;
    } 
    
    if (arraysEqual(checkArray, newArray5 ))
    {
        playerScore = 4;
    }
    
    if (findSequence(arrayFaces) === 3) {
        playerScore = 5;
    }
    
    if ( ( arraysEqual(checkArray2,newArrayA) || arraysEqual(checkArray2,newArrayB) ) )
    {
        playerScore = 6;
    }
    
    if (arraysEqual(checkArray, newArray6 ) || arraysEqual(checkArray, newArray7 ) || arraysEqual(checkArray, newArray8 )
            || arraysEqual(checkArray, newArray10 ) || arraysEqual(checkArray, newArray11 ) || arraysEqual(checkArray, newArray12 ))
    {
        playerScore = 7; //"Two Three of a Kind" or "3 of a kind and two pairs";
    }
    
    if (arraysEqual(checkArray, newArray9))
    {
        playerScore = 8;
    }
    
    if (findSequence(arrayFaces) === 3 && arraysEqual(checkArray2,newArrayA) || 
        findSequence(arrayFaces) === 3 && arraysEqual(checkArray2,newArrayB))
        {
            playerScore = 9;
        }
    
    if   ( (hasAce === true && hasKing === true && hasTen === true && hasQueen === true && hasJack === true) && ( arraysEqual(checkArray2,newArrayA) || arraysEqual(checkArray2,newArrayB) ) )  
         {
            playerScore = 10;
         }
         
         return playerScore;
    //-----------------------------------------------------------------------------------
}

//PLAYER SPECIFIC SCORE HAND FUNCTIONS: 
                   // Uses scoreHand function, with different input arrays (including player-specific cards and community cards)

function scoreHandP1(arrayScoringP1Faces,arrayScoringP1Suits)
{
    p1Score =  scoreHand(arrayScoringP1Faces,arrayScoringP1Suits);
}
function scoreHandP2(arrayScoringP2Faces,arrayScoringP2Suits)
{
    p2Score = scoreHand(arrayScoringP2Faces,arrayScoringP2Suits,p2Score);
}
function scoreHandP3(arrayScoringP3Faces,arrayScoringP3Suits)
{
   p3Score = scoreHand(arrayScoringP3Faces,arrayScoringP3Suits,p3Score);
}
function scoreHandP4(arrayScoringP4Faces,arrayScoringP4Suits)
{
   p4Score = scoreHand(arrayScoringP4Faces,arrayScoringP4Suits,p4Score);
}

//COMPARE SCORES FUNCTION: 
                   // Final scores are determined by the scoreHand functions and their results are put into an array
                   // The scoreArray is looped through to find the player with the highest score or (however unlikely) a if a tie has occured.

function compareScores()
{
    let result = "/WinLoseImages/WinCard.png" //"You Won!"; "/AllCards/2TwoClub.png",
    let highest = 0;
    scoreArray = [p1Score, p2Score, p3Score, p4Score];

    for (let y=0; y< scoreArray.length; y++)
    {
        if (scoreArray[y] >  highest)
        {
        
            highest = scoreArray[y];
            //result = "You lose...";
        }
    }
        if (highest != p1Score) {
          result = "/WinLoseImages/LoseCard.png";
       }

   

    return result;
}

//FIND DUPLICATES FUNCTION: 
                   // Takes in an array as input
                   // Searches through the array for any repeated values
                   // Outputs those repeated values into a new array

function findDuplicates(array) {

    let newArr = [];
    let index = 0;

    for (let i = 0; i < array.length - 1; i++) {
       for (let j = i + 1; j < array.length; j++) {
       if (array[i].valueOf() === array[j].valueOf()) {
             newArr[index] = array[i];
             index++;
          }
       }
    }
     
    let a = [];
    newArr.map(x => !a.includes(x) ? a.push(x) : "");

    return a;
 }

//ARRAYS EQUAL FUNCTION: 
                   // Loops through 2 input arrays in order to determine whether they are equavalent

function arraysEqual(a,b) {
    if (a.length!=b.length)
    {
        return false;
    }
    else
    {
        for(let i=0; i<a.length; i++)    // [2,0,1] nd
        {
            if (a[i]!=b[i])
            {
                return false;
            }else if(i===a.length-1){

              return true;  
            }
            
             
        }
    }
            
}

//CALCULATE DUPLICATES FUNCTION: 
                   // Using the array, outputted from findDuplicates fucntion, as input - as well as the original array (of face values)c-
                   // the function counts how many times the duplicate values (in dupArray) appears in the regArray.
                   // [0,0,0] --> Zero dups - i.e., High Card
                   // [2,0,0] --> 1 dup of 2 - i.e., Pair
                   // [2,2,0] --> 2 dups of 2 - i.e., Two Pair
                   // etc.

 function calcDuplicates(dupArray, regArray){
    let counter = 0;
    let valueArray = [0,0,0];
    

    for (let i = 0; i < dupArray.length; i++) {
        counter =0;
        for (let j = 0; j < regArray.length  ; j++) {
        if (dupArray[i].valueOf() === regArray[j].valueOf()) {
              counter++;
              valueArray[i] = counter;

           }
        }
    }

    return valueArray;
} 

 //FIND SEQUENCE FUNCTION: 
                   // Used when search for straigts (faces in sequence)
                   // Takes in a sorted array as input
                   // Tests how many cards in sequence
                   // If counter === 4 -> 5 cards in sequence, i.e., straight

 function findSequence(array){

    let counter = 0;

    for (let i = 1; i < array.length - 1; i++) {
        if (array[i] === array[i-1]+1) {
            counter++;
        }else if((array[i] != array[i-1]+1) && ( counter!=4 )){
            counter = 0;
        }
        
    }

    return counter;
}

//FISRT ACT OF PLAYER 4 FUNCTION: 
                   // Occurs after the blinds
                   // Player 4 raises
                   // Set occurence at start of game to give a certain start for a single player
                   // ***Will be removed in multiplayer version*** and replaces with Player4AI function 

function firstActP4(){

    P4raiseBetAmount = 20;
    player4_chips = player4_chips - P4raiseBetAmount;
    document.getElementById('player4Chips').innerHTML = `<span>${player4_chips}</span>`;
    //wait(2000);
}

//FLOP START FUNCTION :
                         // Initializes Flop State
                         // First 3 community cards are shown to the player and the text hint is determined by the checkHand function

function FlopStart(){
    document.getElementById('turnIndicator').innerHTML = `<h4>Your Turn</h4>`

    State = "Flop";
    //player 4 checks
    document.getElementById('player4Acts').innerHTML = `<p>Checked</p>`;
    previousBetAmount = 0;//checked
    playerTurn = "myTurn";
    availableButtons()
    //show cards-----------------------------------------------------------------------------------
    document.getElementById('communityCard-1').setAttribute("src", cc1_SrcTemp);
    document.getElementById('communityCard-2').setAttribute("src", cc2_SrcTemp);
    document.getElementById('communityCard-3').setAttribute("src", cc3_SrcTemp);

    //textHint check for hands----------------------------------------------------------------
    checkHandPostFlop();
    
    
}

//TURN START FUNCTION :
                         // Initializes Turn State
                         //4th community card are shown to the player and the text hint is determined by the checkHand function

function TurnStart(){
    
    State = "Turn";
    //show cards
    disableButtons();
    setTimeout(function(){
        document.getElementById('communityCard-4').setAttribute("src", cc4_SrcTemp);
        availableButtons()
    },2600) 
    checkHandPostTurn();
}

//RIVER START FUNCTION :
                         // Initializes River State
                         // 5th community card are shown to the player and the text hint is determined by the checkHand function

function RiverStart(){
   
    State = "River";
    //show cards
    disableButtons();
    setTimeout(function(){
        document.getElementById('communityCard-5').setAttribute("src", cc5_SrcTemp);
        
    },2600)
    

}

//SHOWDOWN START FUNCTION :
                         // Initializes Showdown State
                         // ALL PLAYERS CARDS REVEALED to each other (to single player)


function ShowDownStart(){
   
    State = "Showdown";
    //show cards

    //REMEMBER TO CHECK FOR FOLDS
    //if (player2_folded === false){
        document.getElementById('Player2-card1').setAttribute("src", p2c1_SrcTemp);
        document.getElementById('Player2-card2').setAttribute("src", p2c2_SrcTemp);
    //}
    
    //if (player3_folded === false){
        document.getElementById('Player3-card1').setAttribute("src", p3c1_SrcTemp);
        document.getElementById('Player3-card2').setAttribute("src", p3c2_SrcTemp);
    //}
    
    //if (player4_folded === false){
        document.getElementById('Player4-card1').setAttribute("src", p4c1_SrcTemp);
        document.getElementById('Player4-card2').setAttribute("src", p4c2_SrcTemp);
    //}
    document.getElementById('turnIndicator').style.visibility = "hidden";

    checkHandPostRiver();
   
    document.getElementById('raiseButton').style.visibility = "hidden";
    document.getElementById('callButton').style.visibility = "hidden";
    document.getElementById('foldButton').style.visibility = "hidden";
    document.getElementById('checkButton').style.visibility = "hidden";
    document.getElementById('raiseQuery').style.visibility = "hidden";
    document.getElementById('newGame').style.visibility = "visible";
   
    
    
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

//player actions~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

//CALL ON-CLICK EVENT FUNCTION: 
                   // Runs when player calls
                   // The player simply matches the previous bet (no more, no less)
                   // Then the AI functions run (the other players react)
                   // Certain states (such as preflop) required different functionality for the button

function OnCallClick(){
    //currentBetAmount = previousBetAmount;
    if (State==="River")
    {
        //use currentBetAmount
        currentBetAmount = previousBetAmount;
        document.getElementById('player1Acts').innerHTML = `<p>Called</p>`;
        
        player1_chips = player1_chips - currentBetAmount;
        pot = pot + currentBetAmount;

        document.getElementById('player1Chips').innerHTML = `<span>${player1_chips}</span>`;
        document.getElementById('potChips').innerHTML = `<span>${pot}</span>`;

        previousBetAmount = currentBetAmount;

        //document.getElementById('turnIndicator').innerHTML = `<h4>AI-Johns2005's Turn</h4>`;
        if (state != "Showdown") {
            
        setTimeout(function()
        { 
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-Noluntu's Turn</h4>`;
           
        },1000)   
        Player2AI();
           
        setTimeout(function()
        {
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-David's Turn</h4>`;
            
        },1500) 
        Player3AI();     
        
        setTimeout(function()
        {
            document.getElementById('turnIndicator').innerHTML = `<h4>Your Turn</h4>`;
            
        },2000) 
        Player4AI(); }

    }
    if (State==="Turn")
    {
        //use currentBetAmount
        currentBetAmount = previousBetAmount;
        document.getElementById('player1Acts').innerHTML = `<p>Called</p>`;
        
        player1_chips = player1_chips - currentBetAmount;
        pot = pot + currentBetAmount;

        document.getElementById('player1Chips').innerHTML = `<span>${player1_chips}</span>`;
        document.getElementById('potChips').innerHTML = `<span>${pot}</span>`;

        previousBetAmount = currentBetAmount;

        document.getElementById('turnIndicator').innerHTML = `<h4>AI-Johns2005's Turn</h4>`;
        setTimeout(function()
        { 
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-Noluntu's Turn</h4>`;
            Player2AI();
        },1000)   
           
        setTimeout(function()
        {
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-David's Turn</h4>`;
            Player3AI();
        },1500)      
        
        setTimeout(function()
        {
            document.getElementById('turnIndicator').innerHTML = `<h4>Your Turn</h4>`;
            Player4AI();
        },2000)  

    }
    if (State==="Flop")
    {
        //use currentBetAmount
        currentBetAmount = previousBetAmount;
        document.getElementById('player1Acts').innerHTML = `<p>Called</p>`;
        
        player1_chips = player1_chips - currentBetAmount;
        pot = pot + currentBetAmount;

        document.getElementById('player1Chips').innerHTML = `<span>${player1_chips}</span>`;
        document.getElementById('potChips').innerHTML = `<span>${pot}</span>`;

        previousBetAmount = currentBetAmount;

        document.getElementById('turnIndicator').innerHTML = `<h4>AI-Johns2005's Turn</h4>`;
        setTimeout(function()
        { 
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-Noluntu's Turn</h4>`;
            Player2AI();
        },1000)   
           
        setTimeout(function()
        {
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-David's Turn</h4>`;
            Player3AI();
        },1500)      
        
        setTimeout(function()
        {
            document.getElementById('turnIndicator').innerHTML = `<h4>Your Turn</h4>`;
            Player4AI();
        },2000)  

    }

    if (State === "Preflop")
    {
        player1_chips = player1_chips - P4raiseBetAmount;
        document.getElementById('player1Chips').innerHTML = `<span>${player1_chips}</span>`;
        document.getElementById('player1Acts').innerHTML = `<p>Called</p>`;
        pot = pot + P4raiseBetAmount;
        document.getElementById('potChips').innerHTML = `<span>${pot}</span>`;

        setTimeout(function() {
             currentBetAmount = 15;
             player2_chips = player2_chips - currentBetAmount;
             document.getElementById('player2Acts').innerHTML = `<p>Called</p>`;
             document.getElementById('turnIndicator').innerHTML = `<h4>AI-John2005's Turn</h4>`
             pot = pot + currentBetAmount;

             document.getElementById('player2Chips').innerHTML = `<span>${player2_chips}</span>`;
            document.getElementById('potChips').innerHTML = `<span>${pot}</span>`;
        }, 1000);

        setTimeout(function() {
            currentBetAmount = 10;
            player3_chips = player3_chips - currentBetAmount;
            pot = pot + currentBetAmount;

            document.getElementById('player3Chips').innerHTML = `<span>${player3_chips}</span>`;
            document.getElementById('player3Acts').innerHTML = `<p>Called</p>`;
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-Noluntu's Turn</h4>`
            document.getElementById('potChips').innerHTML = `<span>${pot}</span>`;
        }, 1500);

        setTimeout(function() {
            //player4check------------------------------------------------------------------------------------------------
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-David's Turn</h4>`

            FlopStart();
        
        }, 2000);
    }

    

    disableButtons();
}

//CHECK ON-CLICK EVENT FUNCTION: 
                   // Runs when player checks
                   // The player places no extra chips in the pot (if previous players did not raise)
                   // Initializes the next state

function OnCheckClick(){
    //end betting round
  
    if (State === "River")
    {
        // check if all players have checked.
        if (player1_chips === player2_chips && player1_chips === player3_chips && player1_chips === player4_chips)
        {
            document.getElementById('player1Acts').innerHTML = `<p>Checked</p>`;
            // round ends

            //debug
            //player 2 action
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-Johns2005's Turn</h4>`;
        setTimeout(function()
        { 
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-Noluntu's Turn</h4>`;
            Player2AI();
        },1000)   
           
        setTimeout(function()
        {
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-David's Turn</h4>`;
            Player3AI();
        },1500)      
        
        setTimeout(function()
        {
            document.getElementById('turnIndicator').innerHTML = `<h4>Your Turn</h4>`;
            Player4AI();
        },2000)  

            //availableButtons();
            disableButtons();

            ShowDownStart();
        }
        else
        {
            //player 2 action
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-Johns2005's Turn</h4>`;
        setTimeout(function()
        { 
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-Noluntu's Turn</h4>`;
            Player2AI();
        },1000)   
           
        setTimeout(function()
        {
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-David's Turn</h4>`;
            Player3AI();
        },1500)      
        
        setTimeout(function()
        {
            document.getElementById('turnIndicator').innerHTML = `<h4>Your Turn</h4>`;
            Player4AI();
        },2000)  

        
     

        }
    }

    if (State === "Turn")
    {
        // check if all players have checked.
        if (player1_chips === player2_chips && player1_chips === player3_chips && player1_chips === player4_chips)
        {
            document.getElementById('player1Acts').innerHTML = `<p>Checked</p>`;
            // round ends

            //debug
            //player 2 action
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-Johns2005's Turn</h4>`;
            setTimeout(function()
            { 
                document.getElementById('turnIndicator').innerHTML = `<h4>AI-Noluntu's Turn</h4>`;
                Player2AI();
            },1000)   
               
            setTimeout(function()
            {
                document.getElementById('turnIndicator').innerHTML = `<h4>AI-David's Turn</h4>`;
                Player3AI();
            },1500)      
            
            setTimeout(function()
            {
                document.getElementById('turnIndicator').innerHTML = `<h4>Your Turn</h4>`;
                Player4AI();
            },2000)  

            availableButtons();

            RiverStart();
            
        }
        else
        {
            //player 2 action
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-Johns2005's Turn</h4>`;
        setTimeout(function()
        { 
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-Noluntu's Turn</h4>`;
            Player2AI();
        },1000)   
           
        setTimeout(function()
        {
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-David's Turn</h4>`;
            Player3AI();
        },1500)      
        
        setTimeout(function()
        {
            document.getElementById('turnIndicator').innerHTML = `<h4>Your Turn</h4>`;
            Player4AI();
        },2000) 
        
        

     

        }
    }
    if (State === "Flop")
    {
        // check if all players have checked.
        if (player1_chips === player2_chips && player1_chips === player3_chips && player1_chips === player4_chips)
        {
            document.getElementById('player1Acts').innerHTML = `<p>Checked</p>`;
            // round ends

            //debug
            //player 2 action
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-Johns2005's Turn</h4>`;
        setTimeout(function()
        { 
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-Noluntu's Turn</h4>`;
            Player2AI();
        },1000)   
           
        setTimeout(function()
        {
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-David's Turn</h4>`;
            Player3AI();
        },1500)      
        
        setTimeout(function()
        {
            document.getElementById('turnIndicator').innerHTML = `<h4>Your Turn</h4>`;
            Player4AI();
        },2000)  

            availableButtons();

            TurnStart();

            disableButtons();

            
        }
        
        

    }
    
    
    //disableButtons();
}

//RAISE ON-CLICK EVENT FUNCTION: 
                   // Runs when player raises
                   // The player adds additional chips into the pot
                   // The function pulls from a value the player enters into a number input box next to the button

function OnRaiseClick(){
    currentBetAmount = previousBetAmount;
    playerRaiseAmount = document.querySelector("input").value;

    if (isNaN(playerRaiseAmount)) {
        alert("Please enter a raise value")
    }else if (playerRaiseAmount < 1 || playerRaiseAmount > 200) {
        alert("Place a Bet between 1-200 chips!!!!!!!!!!!!")
    }else if((playerRaiseAmount) > player1_chips)
    {
        alert("You do not have enough chips to raise the bet that high.");//error message to player
    }else if (State != "Showdown")
    {
        currentBetAmount = currentBetAmount + parseInt(playerRaiseAmount);
        document.getElementById('player1Acts').innerHTML = `<p>Raised</p>`;
        
        player1_chips = player1_chips - currentBetAmount;
        pot = pot + currentBetAmount;

        document.getElementById('player1Chips').innerHTML = `<span>${player1_chips}</span>`;
        document.getElementById('potChips').innerHTML = `<span>${pot}</span>`;

        //previousBetAmount = currentBetAmount;
        disableButtons();

        document.getElementById('turnIndicator').innerHTML = `<h4>AI-Johns2005's Turn</h4>`;
        setTimeout(function()
        { 
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-Noluntu's Turn</h4>`;
            Player2AI();
        },1000)   
           
        setTimeout(function()
        {
            document.getElementById('turnIndicator').innerHTML = `<h4>AI-David's Turn</h4>`;
            Player3AI();
        },1500)      
        
        setTimeout(function()
        {
            document.getElementById('turnIndicator').innerHTML = `<h4>Your Turn</h4>`;
            Player4AI();
            availableButtons();
        },2000)  
            
       // Player3AI();
       // Player4AI();
    }

    
}

//FOLD ON-CLICK EVENT FUNCTION: 
                   // Runs when player fold
                   // Since it is single player, the game simple ends for the only player
                   // In multiplayer version - player will be skipped over in following rounds

function OnFoldClick(){
    //end game
    
    disableButtons();
    document.getElementById('gameStatus').style.visibility = "visible";
    document.getElementById('newGame').style.visibility = "visible";
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//available player options~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

//AVAILABLE BUTTONS FUNCTION: 
                   // Enables and disables buttons depending on the current situation the player finds themselves in
                   // For example: if an opponent has raised, the player CANNOT check, only call, raise or fold.

function availableButtons()
{
        if (player1_chips === 0)
        {
            //disable raise
            document.querySelector("#raiseButton").disabled = true; 

        }
        else
        {
            //re-enable raise
            document.querySelector("#raiseButton").disabled = false;
        }

        if (previousBetAmount === 0 || (player1_chips === player2_chips && player1_chips === player3_chips && player1_chips === player4_chips))
        {
            //disable call
            document.querySelector("#callButton").disabled = true; 

            //enable check
            document.querySelector("#checkButton").disabled = false; 
        } else
        {
            //enable call
            document.querySelector("#callButton").disabled = false; 

            //disable check
            document.querySelector("#checkButton").disabled = true;
        }
        
        //enable fold
        document.querySelector("#foldButton").disabled = false; 

}

//DISABLE BUTTONS FUNCTION: 
                   // Disables all buttons (when it is not the players turn - they shouldn't be able to interact with the buttons) 

function disableButtons()
{
    //disable all
    document.querySelector("#foldButton").disabled = true; 
    document.querySelector("#checkButton").disabled = true; 
    document.querySelector("#callButton").disabled = true; 
    document.querySelector("#raiseButton").disabled = true; 
}

//---------------AI-FUNCTIONS---------------------------------------------------------------------------------


//PLAYER2, PLAYER3 AND PLAYER4 AI FUNCTIONS: 
                   // Reacts to player's (and each other's) actions 
                   // If player checks, they check and next game state ensues
                   // If player raises, they call to match the player's bet

function Player2AI()
{
    //debug
    if(player1_chips === player2_chips && player1_chips === player3_chips && player1_chips === player4_chips)
    {
        document.getElementById('player2Acts').innerHTML = `<p>Checked</p>`;
    }
    else 
    {
        currentBetAmount = parseInt(document.querySelector("input").value)//previousBetAmount;
        document.getElementById('player2Acts').innerHTML = `<p>Called</p>`;
        
        player2_chips = player2_chips - currentBetAmount;
        pot = pot + currentBetAmount;

        document.getElementById('player2Chips').innerHTML = `<span>${player2_chips}</span>`;
        document.getElementById('potChips').innerHTML = `<span>${pot}</span>`;

        //previousBetAmount = currentBetAmount;
    }  
}

function Player3AI()
{
    //debug
    if(player1_chips === player2_chips && player1_chips === player3_chips && player1_chips === player4_chips)
    {
        document.getElementById('player3Acts').innerHTML = `<p>Checked</p>`;
    }
    else 
    { 
        currentBetAmount = parseInt(document.querySelector("input").value)    //previousBetAmount;//currentBetAmount = previousBetAmount;
        document.getElementById('player3Acts').innerHTML = `<p>Called</p>`;
        
        player3_chips = player3_chips - currentBetAmount;
        pot = pot + currentBetAmount;

        document.getElementById('player3Chips').innerHTML = `<span>${player3_chips}</span>`;
        document.getElementById('potChips').innerHTML = `<span>${pot}</span>`;

        //previousBetAmount = currentBetAmount;
    }
    

    //checks player 2 prev action

    //checks relative bet amounts

    //check own hand score

    //decides raise, call, check, fold
    
}

function Player4AI()
{
    //debug
    if(player1_chips === player2_chips && player1_chips === player3_chips && player1_chips === player4_chips)
    {
        setTimeout(function(){
           document.getElementById('player4Acts').innerHTML = `<p>Checked</p>`;
        },1500)
        
    }
    else 
    {
        currentBetAmount = parseInt(document.querySelector("input").value)//previousBetAmount;//currentBetAmount = previousBetAmount;
        document.getElementById('player4Acts').innerHTML = `<p>Called</p>`;
        
        player4_chips = player4_chips - currentBetAmount;
        pot = pot + currentBetAmount;

        document.getElementById('player4Chips').innerHTML = `<span>${player4_chips}</span>`;
        document.getElementById('potChips').innerHTML = `<span>${pot}</span>`;

        //previousBetAmount = currentBetAmount;
    }
    
    //checks player 3 prev action

    //checks relative bet amounts

    //check own hand score  

    //decides raise, call, check, fold
    
    //give player control again
    disableButtons();
    availableButtons();
}

//Support for Linux vs Windows
if (navigator.appVersion.indexOf("Linux")!=-1) 
{
    document.body.style.zoom="110%";
}

function refreshPage(){
    window.location.reload();
} 


