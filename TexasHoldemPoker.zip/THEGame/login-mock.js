    let username = ["Ngcweti", "JF_Retief", "Jandre"]

     let password = ["2357649", "2458318", "password"]

function getInfo(){
      

    let testbool = false;

    for (let i = 0; i < username.length; i++) {
       
        if(document.getElementById('Username').value === username[i] && document.getElementById('Password').value === password[i]) {
            testbool = true;
        }
        
    }

    if (testbool) {
        console.log("pass");
        window.location.replace("http://127.0.0.1:5500/LobbyScreen.html");
    } else {
        console.log("fail");
        alert("Please enter correct login details");
    }
    
}

function startGame(){
    window.location.replace("http://127.0.0.1:5500/index.html");
}

function gotoLobby(){
    window.location.replace("http://127.0.0.1:5500/LobbyScreen.html");
}




