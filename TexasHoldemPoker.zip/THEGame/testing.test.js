const {arraysEqual, findDuplicates, calcDuplicates, findSequence, compareScores, checkHand, getInfo} = require('./testing')

test('checking login', () =>{
    expect(getInfo("Ngcweti", "2357649")).toBe(true);// True test case
    expect(getInfo("JF_Retief", "2458318")).toBe(true);// True test case
    expect(getInfo("Jandre", "password")).toBe(true); // True test case
    expect(getInfo("Ngcweti", "2458318")).toBe(false); // false test case
    expect(getInfo("NotAUser", "2357649")).toBe(false); // false test case
   
})

test('checks if arrays are equal', ()=>{
    expect(arraysEqual([0,2,0],[0,2,1])).toBe(false); // First element test case
    expect(arraysEqual([0,2,0],[2,2,1])).toBe(false); // false test case
    expect(arraysEqual([0,2,1],[0,2,1])).toBe(true); // True test case
    expect(arraysEqual([2,2,0],[0,0,0])).toBe(false); // false test case 
   
})

test('find duplicated within array', ()=>{
    expect(findDuplicates([2,2,3,5,6])).toStrictEqual([2]); //single dup test (only "2" is duped)
    expect(findDuplicates([2,2,3,3,3])).toStrictEqual([2,3]); // double dup test ( "2" and "3" is duped)
    expect(findDuplicates(["Heart","Heart","Heart","Heart","Heart"])).toStrictEqual(["Heart"]); //single dup test (only "Heart" is duped)
    expect(findDuplicates(["Heart","Diamond","Spade","Spade","Heart"])).toStrictEqual(["Heart","Spade"]); //double dup test ("Heart" and "Spade" are duped)
    
})

test('calculates the duplicates', ()=>{
    
    expect(calcDuplicates([2],[2,2,3,5,6])).toStrictEqual([2,0,0]); //single dup test (only "2" is duped TWICE)
    expect(calcDuplicates([6,4],[6,6,4,4,4])).toStrictEqual([2,3,0]); // double dup test ( "6" is duped TWICE and "4" is duped THREE TIMES)
    expect(calcDuplicates(["Heart"],["Heart","Heart","Heart","Heart","Heart"])).toStrictEqual([5,0,0]); //single dup test (only "Heart" is duped FIVE TIMES)
    expect(calcDuplicates(["Heart","Spade"],["Heart","Diamond","Spade","Spade","Heart"])).toStrictEqual([2,2,0]); //double dup test ("Heart" and "Spade" are duped TWICE)
})

test('find sequence', ()=>{
    expect(findSequence([2,3,4,1,2,3])).toBe(1); //small sequence at end: NOT A STRAIGHT test case
    expect(findSequence([2,2,4,2,2,3])).toBe(0); //no sequence at end test case
    expect(findSequence([10,13,9,1,4,3])).toBe(0); //no sequence at end test case
    expect(findSequence([1,2,3,11,2,13])).toBe(0); //no sequence at end test case
    expect(findSequence([1,2,3,4,5,3,10])).toBe(4); //straight test case
    
})

test('compare scores', ()=>{
    expect(compareScores(10,2,3,1)).toBe("You Won!"); //win test case
    expect(compareScores(10,9,9,9)).toBe("You Won!"); //win test case
    expect(compareScores(2,10,3,1)).toBe("You Lose..."); //lose test case
})

test('Check Hand', ()=>{
    //test cases fpr all hand types
    expect(checkHand([2,2,3,5,6],['Heart','Spade','Clubs','Diamond','Heart'])).toBe("Pair");
    expect(checkHand([2,2,3,3,3],['Heart','Spade','Clubs','Diamond','Heart'])).toBe("Full House");
    expect(checkHand([3,4,5,6,7,10,11],['Heart','Spade','Clubs','Diamond','Heart','Spade','Clubs'])).toBe("Straight");
    expect(checkHand([2,3,4,5,6,9],['Heart','Heart','Heart','Heart','Heart','Diamond'])).toBe("Straight Flush");
    expect(checkHand([10,11,12,13,1],['Heart','Heart','Heart','Heart','Heart'])).toBe("Royal Flush");
    expect(checkHand([11,1,11,11,11],['Heart','Heart','Heart','Heart','Heart'])).toBe("Four of a Kind");
    expect(checkHand([11,1,1,10,11],['Heart','Heart','Spade','Heart','Heart'])).toBe("Two Pair");
    expect(checkHand([11,1,1,10,1],['Heart','Heart','Spade','Heart','Heart'])).toBe("Three of a Kind");
    expect(checkHand([7,8,2,10,1],['Heart','Heart','Spade','Heart','Heart'])).toBe("High Card");
    expect(checkHand([7,8,2,10,1],['Heart','Heart','Heart','Heart','Heart'])).toBe("Flush");
    
})

