let username = ["Ngcweti", "JF_Retief", "Jandre"]

let password = ["2357649", "2458318", "password"]

function getInfo(a,b){
      

    let testbool = false;

    for (let i = 0; i < username.length; i++) {
       
        if(a === username[i] && b === password[i]) {
            testbool = true;
        }
        
    }

    if (testbool) {
        console.log("pass");
    } else {
        console.log("fail");
    }
    return testbool;
    
}


function arraysEqual(a,b) {
    if (a.length!=b.length)
    {
        return false;
    }
    else
    {
        for(let i=0; i<a.length; i++)    // [2,0,1] nd
        {
            if (a[i]!=b[i])
            {
                return false;
            }else if(i===a.length-1){

              return true;  
            }
            
             
        }
    }
            
}


function findDuplicates(array) {

    let newArr = [];
    let index = 0;

    for (let i = 0; i < array.length - 1; i++) {
       for (let j = i + 1; j < array.length; j++) {
       if (array[i].valueOf() === array[j].valueOf()) {
             newArr[index] = array[i];
             index++;
          }
       }
    }
     
    let a = [];
    newArr.map(x => !a.includes(x) ? a.push(x) : "");

    return a;
 }

 function calcDuplicates(dupArray, regArray){
    let counter = 0;
    let valueArray = [0,0,0];
    

    for (let i = 0; i < dupArray.length; i++) {
        counter =0;
        for (let j = 0; j < regArray.length  ; j++) {
        if (dupArray[i].valueOf() === regArray[j].valueOf()) {
              counter++;
              valueArray[i] = counter;

           }
        }
    }

    return valueArray;
} 

function findSequence(array){

    let counter = 0;

    for (let i = 1; i < array.length - 1; i++) {
        if (array[i] === array[i-1]+1) {
            counter++;
        }else if((array[i] != array[i-1]+1) && ( counter!=4 )){
            counter = 0;
        }
        
    }

    return counter;
}

function compareScores(p1Score, p2Score, p3Score, p4Score)
{
    let result = "You Won!";
    let highest = 0;
    scoreArray = [p1Score, p2Score, p3Score, p4Score];

    for (let y=0; y< scoreArray.length; y++)
    {
        if (scoreArray[y] >  highest)
        {
        
            highest = scoreArray[y];
            //result = "You lose...";
        }
    }
        if (highest != p1Score) {
          result = "You Lose...";
       }

   

    return result;
}
 


function checkHand(arrayFaces,arraySuits)  // [2,2,3,5,6],['Heart','Spade','Clubs','Diamond','Heart']
{
    //check for straights
    arrayFaces = arrayFaces.sort(function (a, b) {  return a - b;  });


    //-----------------------------------------------------------------------------------
    //find what faces are duplicated (for pairs, 3 of a kind, 4 of a kind, full house)
    let dupArray = findDuplicates(arrayFaces);  // [2]
    //make array that shows how many times a card gets duplicated (pair vs 3 of a kind vs ... etc)
    let checkArray = calcDuplicates(dupArray, arrayFaces);  // [2] [2,2,3,5,6] -> [2,0,0]

    let newArray1 = [0,0,0];//High card (no dups)
    let newArray2 = [2,0,0];//Pair (one double)
    let newArray3 = [2,2,0];//two Pair (two doubles)
    let newArray4 = [2,2,2];//three Pair (3 doubles) -> two pair (hand only out of 5 cards)
    let newArray5 = [3,0,0];//3 of a kind (one tripple)
    let newArray6 = [3,3,0];//two 3 of a kind (two tripples) -> full house (hand only out of 5 cards)
    let newArray7 = [3,2,0];//Full house (one tripple and one double)
    let newArray8 = [2,3,0];//Full house (one tripple and one double)
    let newArray9 = [4,0,0];//Four of a Kind (one quad)
    let newArray10 = [3,2,2];//Full house (second pair ignored)
    let newArray11 = [2,3,2];//Full house (second pair ignored)
    let newArray12 = [2,2,3];//Full house (second pair ignored)

    
    //check for royalty
    let hasAce = false;
    let hasKing = false;
    let hasQueen = false;
    let hasJack = false;
    let hasTen = false;
    

    if ( arrayFaces.includes(1)) {
        hasAce = true;
    }
    if ( arrayFaces.includes(13)) {
        hasKing = true;
    }
    if ( arrayFaces.includes(10)) {
        hasTen = true;
    }
    if ( arrayFaces.includes(11)) {
        hasJack = true;
    }
    if ( arrayFaces.includes(12)) {
        hasQueen = true;
    }
    
    //check for flushes
    let dupArray2 = findDuplicates(arraySuits); // dupArray2 = [heart]

    //Two possible checkArray's for a flush
    let newArrayA = [5,0,0];
    let newArrayB = [5,2,0];
    let checkArray2 = calcDuplicates(dupArray2, arraySuits);

    //check which array it is.
    if (arraysEqual(checkArray, newArray1))
    {
        textHint = "High Card";
    }
    
    if (arraysEqual(checkArray, newArray2 ))
    {
        textHint = "Pair";
    }
    
    if (arraysEqual(checkArray, newArray3 ) || arraysEqual(checkArray, newArray4 ))
    {
        textHint = "Two Pair";
    } 
    
    if (arraysEqual(checkArray, newArray5 ))
    {
        textHint = "Three of a Kind";
    }
    
    if (findSequence(arrayFaces) === 4) {
        textHint = "Straight";
    }
    
    if ( ( arraysEqual(checkArray2,newArrayA) || arraysEqual(checkArray2,newArrayB) ) )
    {
        textHint = "Flush";
    }
    
    if (arraysEqual(checkArray, newArray6 ) || arraysEqual(checkArray, newArray7 ) || arraysEqual(checkArray, newArray8 )
            || arraysEqual(checkArray, newArray10 ) || arraysEqual(checkArray, newArray11 ) || arraysEqual(checkArray, newArray12 ))
    {
        textHint = "Full House"; //"Two Three of a Kind" or "3 of a kind and two pairs";
    }
    
    if (arraysEqual(checkArray, newArray9))
    {
        textHint = "Four of a Kind";
    }
    
    if ( (findSequence(arrayFaces) === 4 && arraysEqual(checkArray2,newArrayA)) || 
        (findSequence(arrayFaces) === 4 && arraysEqual(checkArray2,newArrayB)) )
        {
            textHint = "Straight Flush";
        }
    
    if   ( (hasAce === true && hasKing === true && hasTen === true && hasQueen === true && hasJack === true) && ( arraysEqual(checkArray2,newArrayA) || arraysEqual(checkArray2,newArrayB) ) )  
         {
              textHint = "Royal Flush";
         }

            return  textHint;

    
    
    //-----------------------------------------------------------------------------------
}


module.exports = {arraysEqual, findDuplicates, calcDuplicates, findSequence, compareScores, checkHand, getInfo};